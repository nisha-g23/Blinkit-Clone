import 'package:flutter/material.dart';

class AppColors{
  static const Color scaffoldbackgroud=Color(0XFFF7CB45);
}